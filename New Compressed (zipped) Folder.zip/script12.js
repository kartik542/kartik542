function myMenuFunction(){
 var menuBth = document.getElementById("myNavMenu");
 
 if(menuBth.className === "nav-menu"){
    menuBth.className += "responsive";
 } else{
    menuBth.className = "nav-menu";
 }
}

 /* ###################### Typing Effect ##########################*/

 var typingEffect = new Typed(".typedText", {
   String: ["Desinger", "Coder", "Developer"],
   
   loop: true,
   TypedSpeed: 100,
   backSpeed: 80,
   backDelay: 2000,
 })

 /* #################################### Scroll Animation ############################ */

 const sr = scrollReveal({
   origin: "top",
   distance:"80px",
   duration: 2000,
   reset: true,
 });

 sr.reveal(".featured.name", {dealay: 100});
 sr.reveal(".text-info", {dealay: 200});
 sr.reveal(".text-btn", {dealay: 200});
 sr.reveal(".social_icons", {dealay: 200});
 sr.reveal(".featured-image", {dealay: 320});

 sr.reveal(".project-box", {interval: 200});
 sr.reveal(".top-header", {});

 const srleft = scrollReveal({
   origin: "left",
   distance: "80px"
   duration: 2000,
   reset: true,
 })

 srleft.reveal(".about-info", {dealay: 100});
 srleft.reveal(".contact-info", {dealay: 100});

 const srRight = scrollReveal({
   origin: "left",
   distance: "80px"
   duration: 2000,
   reset: true,
 })

 srRight.reveal(".skill", {dealay: 100});
 srRight.reveal(".skill-box", {dealay: 100});

 /* ################################# Active Link ############################### */

 const sections = document.querySelectorAll(".section[id]");

 function scrollActive(){
   const ScrollY = window.scrollY;

   sections.forEach({current} => {
         
      const sectionHeight = current.offsetHeight,
      sectionTop = current.offSetTop - 50,
      sectionId = current.getAttribute("id");

      if(scrolllY > sectionTop && scrollY <= sectionTop + sectionHeight){
         document
         .querySelector(".nav-menu a[href*=" + sectionId + "]")
         .classList.add ("active-link");

      }
   });
 }

 window.addEventListener("scroll", scrollActive);
 



